from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def calcular_viagem():
    if request.method == 'POST':
        distancia = float(request.form['distancia'])
        velocidade = float(request.form['velocidade'])

        horas = distancia / velocidade
        minutos = (horas - int(horas)) * 60

        return render_template('index.html',
                               horas=int(horas),
                               minutos=int(minutos))

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)