from flask import Flask, render_template, request

app = Flask(__name__)

# Taxas de conversão (fixas)
TAXAS = {
    'dolar': 5.30,  # 1 dólar = 5.30 reais
    'euro': 5.80     # 1 euro = 5.80 reais
}

@app.route('/', methods=['GET', 'POST'])
def converter():
    resultado = None
    if request.method == 'POST':
        valor_reais = float(request.form['valor'])
        moeda = request.form['moeda']
        taxa = TAXAS[moeda]
        valor_convertido = valor_reais / taxa
        resultado = {
            'moeda': moeda.upper(),
            'valor': f"{valor_convertido:.2f}"
        }
    return render_template('index.html', resultado=resultado)

if __name__ == '__main__':
    app.run(debug=True)