from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def converter():
    if request.method == 'POST':
        celsius = float(request.form['celsius'])
        fahrenheit = (celsius * 9/5) + 32
        kelvin = celsius + 273.15
        return render_template('index.html',
                            celsius=celsius,
                            fahrenheit=round(fahrenheit, 2),
                            kelvin=round(kelvin, 2))
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)