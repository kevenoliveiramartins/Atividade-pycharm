from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def calcular_media():
    if request.method == 'POST':
        nota1 = float(request.form['nota1'])
        nota2 = float(request.form['nota2'])
        nota3 = float(request.form['nota3'])

        media = (nota1 + nota2 + nota3) / 3
        situacao = "Aprovado" if media >= 7 else "Reprovado"

        return render_template('index.html',
                               media=f"{media:.2f}",
                               situacao=situacao)

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)