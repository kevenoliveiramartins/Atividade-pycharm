from flask import Flask, render_template, request
from datetime import datetime

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html', ano_atual=datetime.now().year)


@app.route('/calcular', methods=['POST'])
def calcular():
    try:

        if 'ano_nascimento' not in request.form or not request.form['ano_nascimento'].strip():
            return render_template('index.html',
                                   mensagem_erro="Por favor, informe o ano de nascimento",
                                   ano_atual=datetime.now().year)


        try:
            ano_nascimento = int(request.form['ano_nascimento'])
        except ValueError:
            return render_template('index.html',
                                   mensagem_erro="Por favor, digite um ano válido (apenas números)",
                                   ano_atual=datetime.now().year)

        ano_atual = datetime.now().year


        if ano_nascimento < 1900:
            return render_template('index.html',
                                   mensagem_erro="Ano de nascimento deve ser maior que 1900",
                                   ano_atual=ano_atual)

        if ano_nascimento > ano_atual:
            return render_template('index.html',
                                   mensagem_erro=f"Ano de nascimento não pode ser maior que {ano_atual}",
                                   ano_atual=ano_atual)

        # Cálculo da idade
        idade = ano_atual - ano_nascimento


        return render_template('index.html',
                               idade=idade,
                               ano_nascimento=ano_nascimento,
                               ano_atual=ano_atual)

    except Exception as e:

        app.logger.error(f"Erro inesperado: {str(e)}")
        return render_template('index.html',
                               mensagem_erro="Ocorreu um erro inesperado. Tente novamente.",
                               ano_atual=datetime.now().year)


if __name__ == '__main__':
    app.run(debug=True)